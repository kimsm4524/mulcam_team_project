package com.example.kimsm.soccerproject;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class SendSignup extends AppCompatActivity {
    String id;
    String pass;
    String city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_signup);
        Intent i = getIntent();
        id = i.getStringExtra("id");
        pass = i.getStringExtra("pass");
        city = i.getStringExtra("city");
        DataAsync data = new DataAsync();
        data.execute();

    }

    class DataAsync extends AsyncTask<Void, String, Void> {
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            Toast.makeText(SendSignup.this, values[0], Toast.LENGTH_SHORT).show();
            finish();
        }

        @Override
        protected Void doInBackground(Void... voids) {//user thread
            String url = "http://70.12.246.27:7070/ProjectServer/login.jsp";
            String param = "?id=" + id + "&pass=" + pass + "&city=" + city;
            Log.i("zzzzzzzzzzz:",url+param);
            Document xml = null;
            String u = url + param;
            try {
                xml = Jsoup.connect(u).get();//url에 접속해서 xml파일을 받아옴
            } catch (IOException e) {
                e.printStackTrace();
            }
            Elements result = xml.select("data");
            for(Element e:result)
                publishProgress(e.select("result").text());
                //Toast.makeText(SendSignup.this, e.select("result").text(), Toast.LENGTH_SHORT).show();

            //element data를 찾음<data>~</data>
            Elements items = xml.select("item");


//            for(Element e: items){
//                String id = e.select("id").text();
//                String name = e.select("name").text();
//                String phone = e.select("phone").text();
//                String address = e.select("address").text();
//                String company = e.select("company").text();
//            }
            return null;
        }
    }
}
