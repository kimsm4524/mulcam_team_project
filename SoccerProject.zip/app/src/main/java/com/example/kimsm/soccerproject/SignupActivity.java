package com.example.kimsm.soccerproject;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {
EditText new_id;
EditText new_pass;
EditText pass_check;
EditText city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        new_id = (EditText)findViewById(R.id.new_id);
        new_pass = (EditText)findViewById(R.id.new_pass);
        pass_check = (EditText)findViewById(R.id.pass_check);
        city = (EditText)findViewById(R.id.city);
    }
    public void approve(View v)
    {

        String id = new_id.getText().toString();
        String pass = new_pass.getText().toString();
        String check = pass_check.getText().toString();
        String ct = city.getText().toString();
        if(pass.equals(check)) {
            Intent i = new Intent(this,SendSignup.class);
            i.putExtra("id",id);
            i.putExtra("pass",pass);
            i.putExtra("city",ct);
            startActivityForResult(i,100);
         }
        else
        {
            new_id.setText("");
            new_pass.setText("");
            pass_check.setText("");
            city.setText("");
            Toast.makeText(this, "비밀번호가 일치 하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

    }
}
