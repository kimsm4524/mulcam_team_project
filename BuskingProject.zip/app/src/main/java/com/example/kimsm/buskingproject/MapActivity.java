package com.example.kimsm.buskingproject;
import android.Manifest;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {
    FusedLocationProviderClient mFusedLocationClient;
    LocationCallback mLocationCallback;
    Location mCurrentLocation;
    GoogleMap Mmap;
    boolean mLocationPermissionGranted;
    LocationRequest mLocationRequest;
    LocationManager manager;
    ArrayList<String> locx;
    ArrayList<String> locy;
    ArrayList<String> ti;
    ArrayList<String> teamname;
    ArrayList<String>  info;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        FragmentManager fragmentManager = getFragmentManager();
        MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.map);
        mapFragment.getMapAsync((OnMapReadyCallback) this);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        manager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        Intent i =getIntent();
        locx = i.getStringArrayListExtra("locx");
        locy = i.getStringArrayListExtra("locy");
        ti = i.getStringArrayListExtra("ti");
        teamname = i.getStringArrayListExtra("teamname");
        info = i.getStringArrayListExtra("info");
    }

    @Override
    public void onMapReady(GoogleMap map) {

        Mmap = map;
        Toast.makeText(this,"현재위치",Toast.LENGTH_LONG).show();
        MarkerOptions markerOptions = new MarkerOptions();
        for(int i=0;i<locx.size();i++)
        {
            LatLng loc = new LatLng(Double.parseDouble(locx.get(i)),Double.parseDouble(locy.get(i)));
            markerOptions.position(loc);
            markerOptions.title(teamname.get(i));
            markerOptions.snippet(info.get(i));
            map.addMarker(markerOptions);
            map.moveCamera(CameraUpdateFactory.newLatLng(loc));
            map.animateCamera(CameraUpdateFactory.zoomTo(17));
        }

    }



}
