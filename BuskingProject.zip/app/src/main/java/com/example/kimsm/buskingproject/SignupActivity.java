package com.example.kimsm.buskingproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class SignupActivity extends AppCompatActivity {
EditText new_id;
EditText new_pass;
EditText pass_check;
EditText city;
EditText teamname;
ArrayList<EditText> records;
LinearLayout vis1,vis2,vis3,vis4;
ArrayList<LinearLayout> vis;
EditText intro;
EditText link;
EditText cloud;
EditText members;
int recordnum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        new_id = (EditText)findViewById(R.id.new_id);
        new_pass = (EditText)findViewById(R.id.new_pass);
        pass_check = (EditText)findViewById(R.id.pass_check);
        city = (EditText)findViewById(R.id.city);
        teamname = (EditText)findViewById(R.id.teamname);
        records = new ArrayList<EditText>();
        records.add((EditText)findViewById(R.id.record));
        records.add((EditText)findViewById(R.id.record1));
        records.add((EditText)findViewById(R.id.record2));
        records.add((EditText)findViewById(R.id.record3));
        records.add((EditText)findViewById(R.id.record4));
        vis = new ArrayList<LinearLayout>();
        vis.add((LinearLayout)findViewById(R.id.vis1));
        vis.add((LinearLayout)findViewById(R.id.vis2));
        vis.add((LinearLayout)findViewById(R.id.vis3));
        vis.add((LinearLayout)findViewById(R.id.vis4));
        intro = (EditText)findViewById(R.id.intro);
        link = (EditText)findViewById(R.id.link);
        cloud = (EditText)findViewById(R.id.cloud);
        members = (EditText)findViewById(R.id.members);
        recordnum=1;
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 100) {
            if(resultCode == 200){
                finish();
            }
        }
    }
    public void addm(View v) {
        if(v.getId()==R.id.button3) {
            if (recordnum < 5) {
                vis.get(recordnum - 1).setVisibility(View.VISIBLE);
                recordnum++;
            }
        }

        if(v.getId()==R.id.button4) {
            if (recordnum > 1) {
                vis.get(recordnum - 2).setVisibility(View.GONE);
                recordnum--;
            }
        }
    }
    public void approve(View v)
    {

        String id = new_id.getText().toString();
        String pass = new_pass.getText().toString();
        String check = pass_check.getText().toString();
        String ct = city.getText().toString();
        ArrayList<String> recordt = new ArrayList<String>();
        for(int i = 0; i<recordnum;i++)
            recordt.add(records.get(i).getText().toString());

        if(pass.equals(check)) {
            Intent i = new Intent(this,SendSignup.class);
            i.putExtra("id",id);
            i.putExtra("pass",pass);
            i.putExtra("city",ct);
            i.putExtra("teamname",teamname.getText().toString());
            i.putStringArrayListExtra("records",recordt);
            i.putExtra("intro",intro.getText().toString());
            i.putExtra("link",link.getText().toString());
            i.putExtra("cloud",cloud.getText().toString());
            i.putExtra("members",members.getText().toString());
            i.putExtra("recordnum",recordnum);

            startActivityForResult(i,100);
         }
        else
        {
            new_id.setText("");
            new_pass.setText("");
            pass_check.setText("");
            city.setText("");
            Toast.makeText(this, "비밀번호가 일치 하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

    }
}
