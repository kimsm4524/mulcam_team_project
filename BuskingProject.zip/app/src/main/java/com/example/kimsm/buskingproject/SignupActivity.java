package com.example.kimsm.buskingproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class SignupActivity extends AppCompatActivity {
EditText new_id;
EditText new_pass;
EditText pass_check;
EditText name;
EditText nickname;
EditText email;
EditText phone;
ArrayList<EditText> genres;
ArrayList<EditText> spots;
LinearLayout ge1,ge2;
LinearLayout sp1,sp2;
ArrayList<LinearLayout> ge;
ArrayList<LinearLayout> sp;
int genrenum, spotnum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        new_id = (EditText)findViewById(R.id.new_id);
        new_pass = (EditText)findViewById(R.id.new_pass);
        pass_check = (EditText)findViewById(R.id.pass_check);
        name = (EditText)findViewById(R.id.name);
        nickname = (EditText)findViewById(R.id.nickname);
        email = (EditText)findViewById(R.id.email);
        phone = (EditText)findViewById(R.id.phone);
        genres = new ArrayList<EditText>();
        spots = new ArrayList<EditText>();
        genres.add((EditText)findViewById(R.id.genre));
        genres.add((EditText)findViewById(R.id.genre1));
        genres.add((EditText)findViewById(R.id.genre2));
        spots.add((EditText)findViewById(R.id.spot));
        spots.add((EditText)findViewById(R.id.spot1));
        spots.add((EditText)findViewById(R.id.spot2));
        ge = new ArrayList<LinearLayout>();
        ge.add((LinearLayout)findViewById(R.id.ge1));
        ge.add((LinearLayout)findViewById(R.id.ge2));
        sp = new ArrayList<LinearLayout>();
        sp.add((LinearLayout)findViewById(R.id.sp1));
        sp.add((LinearLayout)findViewById(R.id.sp2));
        genrenum=1;
        spotnum=1;
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 100) {
            if(resultCode == 200){
                finish();
            }
        }
    }
    public void addm(View v) {
        if(v.getId()==R.id.genrep) {
            if (genrenum < 3) {
                ge.get(genrenum - 1).setVisibility(View.VISIBLE);
                genrenum++;
            }
        }

        if(v.getId()==R.id.genrem) {
            if (genrenum > 1) {
                ge.get(genrenum - 2).setVisibility(View.GONE);
                genrenum--;
            }
        }
        if(v.getId()==R.id.spotp) {
            if (spotnum < 3) {
                sp.get(spotnum - 1).setVisibility(View.VISIBLE);
                spotnum++;
            }
        }

        if(v.getId()==R.id.spotm) {
            if (spotnum > 1) {
                sp.get(spotnum - 2).setVisibility(View.GONE);
                spotnum--;
            }
        }
    }
    public void approve(View v)
    {

        String id = new_id.getText().toString();
        String pass = new_pass.getText().toString();
        String check = pass_check.getText().toString();
        String namet = name.getText().toString();
        String nicknamet = nickname.getText().toString();
        String emailt = email.getText().toString();
        String phonet = phone.getText().toString();
        ArrayList<String> genret = new ArrayList<String>();
        ArrayList<String> spott = new ArrayList<String>();
        for(int i = 0; i<genrenum;i++)
            genret.add(genres.get(i).getText().toString());
        for(int i = 0; i<spotnum;i++)
            spott.add(spots.get(i).getText().toString());

        if(pass.equals(check)) {
            Intent i = new Intent(this,SendSignup.class);
            i.putExtra("id",id);
            i.putExtra("pass",pass);
            i.putExtra("name",namet);
            i.putExtra("nickname",nicknamet);
            i.putExtra("email",emailt);
            i.putExtra("phone",phonet);
            i.putStringArrayListExtra("genres",genret);
            i.putStringArrayListExtra("spots",spott);
            i.putExtra("genrenum",genrenum);
            i.putExtra("spotnum",spotnum);

            startActivityForResult(i,100);
         }
        else
        {
            new_pass.setText("");
            pass_check.setText("");
            Toast.makeText(this, "비밀번호가 일치 하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

    }
}
