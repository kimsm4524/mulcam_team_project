package com.example.kimsm.buskingproject;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.android.gms.maps.model.LatLng;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MapDataActivity extends AppCompatActivity {
    ArrayList<String> teamname;
    ArrayList<String> locx;
    ArrayList<String> locy;
    ArrayList<String> ti;
    ArrayList<String> info;
    Time time;
    String formatDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_data);
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdfNow = new SimpleDateFormat("HH:mm");
        formatDate = sdfNow.format(date);
        teamname = new ArrayList<>();
        locx = new ArrayList<>();
        locy = new ArrayList<>();
        ti = new ArrayList<>();
        info = new ArrayList<>();
        DataAsync data = new DataAsync();
        data.execute();
    }
    class DataAsync extends AsyncTask<Void, String, Void> {
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            Intent i = new Intent(MapDataActivity.this,MapActivity.class);
            i.putStringArrayListExtra("locx",locx);
            i.putStringArrayListExtra("locy",locy);
            i.putStringArrayListExtra("ti",ti);
            i.putStringArrayListExtra("teamname",teamname);
            i.putStringArrayListExtra("info",info);
            startActivity(i);
        }

        protected Void doInBackground(Void... voids) {//user thread
            String url = "http://70.12.246.27:7070/ProjectServer/mapinfo.jsp";
            Document xml = null;
            try {
                xml = Jsoup.connect(url).get();//url에 접속해서 xml파일을 받아옴
            } catch (IOException e) {
                e.printStackTrace();
            }
            Elements result = xml.select("data");
            int i=0;
            for (Element e : result) {
                teamname.add(e.select("TEAMNAME").text().toString());
                locx.add(e.select("LOCX").text().toString());
                locy.add(e.select("LOCY").text().toString());
                ti.add(e.select("TIME").text().toString());
                info.add(e.select("INTRO").text().toString());
            }
            publishProgress();
            return null;
        }
    }
}
