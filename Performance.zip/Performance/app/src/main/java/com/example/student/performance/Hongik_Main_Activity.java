package com.example.student.performance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;

public class Hongik_Main_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hongik__main_);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public  class TestImageGalleryActivity extends AppCompatActivity {
        public  static final int MAX_ROW_COUNT = 3;
        private ImageView m_reflmageGalleryViewArray[][] = new ImageView[MAX_ROW_COUNT][];

    }

    public void access_account(MenuItem item) {
        Intent i = new Intent(this, Account_Activity.class);
        startActivity(i);
    }
}
