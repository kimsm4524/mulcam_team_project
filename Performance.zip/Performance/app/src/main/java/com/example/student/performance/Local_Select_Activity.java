package com.example.student.performance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Local_Select_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local__select_);
    }


    public void hongik_select(View view) {
        Intent i = new Intent(this, Hongik_Main_Activity.class);
        startActivity(i);
    }
}
